// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault(); // Prevent default anchor behavior
    const targetId = this.getAttribute('href'); // Get the target section ID
    const targetSection = document.querySelector(targetId); // Find the target section
    if (targetSection) {
      targetSection.scrollIntoView({ behavior: 'smooth' }); // Smooth scroll to the section
    }
  });
});

// Show the Contact Section when the Contact link is clicked (for index.html)
if (document.querySelector('a[href="#contact"]')) {
  document.querySelector('a[href="#contact"]').addEventListener('click', function (e) {
    e.preventDefault(); // Prevent default anchor behavior
    const contactSection = document.querySelector('#contact'); // Get the Contact Section
    if (contactSection) {
      contactSection.classList.remove('hidden'); // Remove the hidden class
      contactSection.scrollIntoView({ behavior: 'smooth' }); // Smooth scroll to the section
    }
  });
}

// Handle form submissions for Login and Signup pages
if (window.location.pathname.includes('login.html')) {
  document.getElementById('login-form').addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent form submission
    alert('Login successful!'); // Replace with actual login logic
    window.location.href = 'index.html'; // Redirect to the home page
  });
}

if (window.location.pathname.includes('signup.html')) {
  document.getElementById('signup-form').addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent form submission
    alert('Signup successful!'); // Replace with actual signup logic
    window.location.href = 'index.html'; // Redirect to the home page
  });
}

// Handle Contact Form Submission (for contact.html)
if (window.location.pathname.includes('contact.html')) {
  document.getElementById('contact-form').addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent form submission
    alert('Thank you for your message! We will get back to you soon.');
    e.target.reset(); // Clear the form
  });
}

// Dark Mode Toggle
const darkModeToggle = document.getElementById('dark-mode');
if (darkModeToggle) {
  darkModeToggle.addEventListener('change', function () {
    document.body.classList.toggle('dark-mode', this.checked);
  });
}
// Add an event listener to the "Get Started" button
document.getElementById('getStartedButton').addEventListener('click', function() {
  // Redirect to the payments page
  window.location.href = 'payments.html'; // Replace with the actual path to your payments page
});